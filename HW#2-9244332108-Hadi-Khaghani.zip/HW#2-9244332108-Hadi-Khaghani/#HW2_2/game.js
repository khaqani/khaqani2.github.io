﻿var cards = ['A', 'A', 'B', 'B', 'C', 'C', 'D', 'D', 'E', 'E', 'F', 'F', 'G', 'G', 'H', 'H', 'I', 'I', 'J', 'J'];
var cardValue = [];
var cardID = [];
var cardFound = 0;
Array.prototype.shuffle = function () {
    var i = this.length, j, temp;
    while (--i > 0) {
        j = Math.floor(Math.random() * (i + 1));
        temp = this[j];
        this[j] = this[i];
        this[i] = temp;
    }
}

function startGame() {
    cardFound = 0;
    var output = '';
    cards.shuffle();
    for (var i = 0; i < cards.length; i++) {
        output += '<div id="card' + i + '" onclick="cardFlip(this,\'' + cards[i] + '\')"></div>';
    }
    document.getElementById('showCards').innerHTML = output;
    window.timer = setTimeout(function () {
        alert("متاسفم باختید، شما بایستی تصاویر را در مدت یک دقیقه حدس بزنید!");
        startGame();
    }, 60000);
}

function cardFlip(card, val) {
    if (cardValue.length < 2) {
        card.style.background = 'url(img/img_' + val + '.jpg) no-repeat';

        if (cardValue.length == 0) {
            cardValue.push(val);
            cardID.push(card.id);
        }
        else if (cardValue.length == 1) {
            cardValue.push(val);
            cardID.push(card.id);

            if ((cardValue[0] == cardValue[1]) && (cardID[0] != cardID[1])) {
                cardFound += 2;
                cardValue = [];
                cardID = [];

                if (cardFound == cards.length) {
                    clearTimeout(timer);
                    alert("تبریک، شما توانستید کمتر از یک دقیقه تصاویر را حدس بزنید");
                    startGame();
                }
            }
            else {
                function backFlip() {
                    var card_1 = document.getElementById(cardID[0]);
                    var card_2 = document.getElementById(cardID[1]);
                    card_1.style.background = 'url(img/bg.jpg) no-repeat';
                    card_2.style.background = 'url(img/bg.jpg) no-repeat';
                    cardValue = [];
                    cardID = [];
                }
                setTimeout(backFlip, 800);
            }
        }
    }
}